from django.db import models
from patients.models import Patient

class Instrument(models.Model):
    CATEGORY_CHOICES = [
        ('mood', 'Estado de Ánimo'),
        ('neuro', 'Evaluación Neuropsicológica'),
        ('interview', 'Entrevistas'),
        ('forms', 'Formatería'),
    ]

    SUBCATEGORY_CHOICES = [
        # Mood
        ('depression', 'Depresión'),
        ('anxiety', 'Ansiedad'),
        ('self_harm', 'Autolesivos'),
        # Neuro
        ('mental_status', 'Estado Mental'),
        ('executive_functions', 'Funciones Ejecutivas'),
        ('perception', 'Percepción'),
        ('intelligence', 'Inteligencia'),
        ('damage', 'Evaluaciones por Daño'),
        # Interviews
        ('clinical', 'Clínica'),
        ('cbt', 'Cognitivo Conductual'),
        ('afc', 'AFC'),
        # Forms
        ('general', 'General'),
    ]

    name = models.CharField(max_length=200)
    description = models.TextField()
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES, default='mood')
    subcategory = models.CharField(max_length=50, choices=SUBCATEGORY_CHOICES, blank=True, null=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return self.name

class Question(models.Model):
    instrument = models.ForeignKey(Instrument, related_name='questions', on_delete=models.CASCADE)
    text = models.TextField()
    order = models.IntegerField(default=0)
    question_type = models.CharField(max_length=50, choices=[('text', 'Text'), ('choice', 'Choice'), ('likert', 'Likert')])
    options = models.JSONField(default=list, blank=True) 

    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.text[:50]

class Assessment(models.Model):
    patient = models.ForeignKey(Patient, related_name='assessments', on_delete=models.CASCADE)
    instrument = models.ForeignKey(Instrument, on_delete=models.CASCADE)
    date_assigned = models.DateTimeField(auto_now_add=True)
    date_completed = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, default='pending') 

class Response(models.Model):
    assessment = models.ForeignKey(Assessment, related_name='responses', on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    answer_text = models.TextField(blank=True) 
    answer_value = models.IntegerField(null=True, blank=True) 

class AssessmentResult(models.Model):
    assessment = models.OneToOneField(Assessment, related_name='result', on_delete=models.CASCADE)
    score = models.FloatField(null=True, blank=True)
    interpretation = models.TextField(blank=True)
    generated_at = models.DateTimeField(auto_now_add=True)
