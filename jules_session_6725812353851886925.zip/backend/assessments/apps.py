from django.apps import AppConfig


class AssessmentsConfig(AppConfig):
    name = "assessments"
