from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from .models import Instrument, Question, Assessment, Patient

class AssessmentTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.patient = Patient.objects.create(
            first_name="John", paternal_last_name="Doe", date_of_birth="1990-01-01", gender="Masculino"
        )
        self.instrument = Instrument.objects.create(name="Depression Scale", description="Test")
        self.question = Question.objects.create(
            instrument=self.instrument, text="I feel sad", question_type="likert"
        )
        self.assessment = Assessment.objects.create(patient=self.patient, instrument=self.instrument)

    def test_submit_responses_and_score(self):
        url = f'/api/assessments/{self.assessment.id}/submit_responses/'
        data = {
            'responses': [
                {'question_id': self.question.id, 'value': 5}
            ]
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        # Check if result was created
        self.assessment.refresh_from_db()
        self.assertEqual(self.assessment.status, 'completed')
        self.assertTrue(hasattr(self.assessment, 'result'))
        self.assertEqual(self.assessment.result.score, 5)
