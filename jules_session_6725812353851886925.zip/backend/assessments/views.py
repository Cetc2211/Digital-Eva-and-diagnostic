from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response as APIResponse
from .models import Instrument, Question, Assessment, Response, AssessmentResult
from .serializers import (
    InstrumentSerializer, QuestionSerializer, AssessmentSerializer, 
    ResponseSerializer, AssessmentResultSerializer
)

class InstrumentViewSet(viewsets.ModelViewSet):
    queryset = Instrument.objects.all()
    serializer_class = InstrumentSerializer

class AssessmentViewSet(viewsets.ModelViewSet):
    queryset = Assessment.objects.all()
    serializer_class = AssessmentSerializer

    @action(detail=True, methods=['post'])
    def submit_responses(self, request, pk=None):
        assessment = self.get_object()
        data = request.data.get('responses', [])
        
        # Simple Logic: Save responses
        for item in data:
            question_id = item.get('question_id')
            value = item.get('value')
            text = item.get('text', '')
            
            question = Question.objects.get(id=question_id)
            Response.objects.create(
                assessment=assessment,
                question=question,
                answer_value=value if isinstance(value, int) else None,
                answer_text=text
            )
        
        assessment.status = 'completed'
        assessment.save()
        
        # Trigger Auto-Scoring (Mock Logic)
        self._calculate_score(assessment)
        
        return APIResponse({'status': 'responses saved and scored'})

    def _calculate_score(self, assessment):
        # Example Logic: Sum of all answer_values
        total_score = 0
        responses = assessment.responses.all()
        for r in responses:
            if r.answer_value is not None:
                total_score += r.answer_value
        
        # Interpretation
        interpretation = "Normal"
        if total_score > 10:
            interpretation = "High"
            
        AssessmentResult.objects.create(
            assessment=assessment,
            score=total_score,
            interpretation=interpretation
        )
